import MusicPlayer from "@/components/MusicPlayer";

export default function Home() {
  return (
    <div className="bg-background text-foreground min-h-screen font-sans">
      <MusicPlayer />
    </div>
  );
}
